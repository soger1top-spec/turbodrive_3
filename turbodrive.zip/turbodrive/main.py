
# =========================================================
# TURBO DRIVE - MOBILE
# Python + Kivy
# =========================================================

from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.scrollview import ScrollView
from kivy.uix.progressbar import ProgressBar
from kivy.clock import Clock
from kivy.core.window import Window


# =========================================================
# إعدادات النافذة عند التجربة على الكمبيوتر
# =========================================================

Window.size = (420, 760)


# =========================================================
# بيانات اللعبة
# =========================================================

money = 0.0

car_levels = {
    "engine": 1,
    "turbo": 1,
    "tires": 1,
    "bumper": 1,
    "hood": 1,
    "fuel": 1,
}

selected_part = "engine"
# =========================================================
# أسماء القطع
# =========================================================

part_names = {
    "engine": "ENGINE",
    "turbo": "TURBO",
    "tires": "TIRES",
    "bumper": "BUMPER",
    "hood": "HOOD",
    "fuel": "FUEL TANK",
}


# =========================================================
# الأسعار
# =========================================================

part_prices = {
    "engine": 1000,
    "turbo": 500,
    "tires": 30,
    "bumper": 50,
    "hood": 60,
    "fuel": 100,
}


# =========================================================
# فائدة القطع
# =========================================================

part_benefits = {
    "engine": "MORE POWER",
    "turbo": "MORE SPEED",
    "tires": "BETTER CONTROL",
    "bumper": "MORE MONEY",
    "hood": "MORE DURABILITY",
    "fuel": "MORE FUEL",
}


# =========================================================
# مضاعف كل قطعة
# =========================================================

part_multipliers = {
    "tires": 1,
    "bumper": 2,
    "hood": 3,
    "fuel": 4,
    "turbo": 5,
    "engine": 10,
}


parts = [
    "engine",
    "turbo",
    "tires",
    "bumper",
    "hood",
    "fuel",
]


# =========================================================
# السعر القادم
# =========================================================

def get_price(part):

    level = car_levels[part]

    return int(
        part_prices[part] * (1.5 ** (level - 1))
    )


# =========================================================
# مضاعف المال
# =========================================================

def get_profit_multiplier():

    multiplier = 1.0

    for part in parts:

        purchased_levels = car_levels[part] - 1

        if purchased_levels > 0:

            multiplier += (
                purchased_levels
                * part_multipliers[part]
            )

    return multiplier


# =========================================================
# سرعة السيارة
# =========================================================

def get_speed():

    engine_bonus = (
        (car_levels["engine"] - 1) * 10
    )

    turbo_bonus = (
        (car_levels["turbo"] - 1) * 20
    )

    return 100 + engine_bonus + turbo_bonus


# =========================================================
# البنزين
# =========================================================

def get_fuel():

    return (
        100
        + (car_levels["fuel"] - 1) * 25
    )


# =========================================================
# التحكم
# =========================================================

def get_control():

    return (
        100
        + (car_levels["tires"] - 1) * 10
    )


# =========================================================
# التحمل
# =========================================================

def get_durability():

    return (
        100
        + (car_levels["hood"] - 1) * 10
    )


# =========================================================
# ألوان
# =========================================================

BG = (0.04, 0.05, 0.07, 1)
BLUE = (0.05, 0.45, 0.95, 1)
DARK_BLUE = (0.03, 0.20, 0.40, 1)
GRAY = (0.16, 0.18, 0.22, 1)
WHITE = (0.95, 0.95, 0.95, 1)
GOLD = (0.95, 0.70, 0.15, 1)
GREEN = (0.15, 0.75, 0.35, 1)


# =========================================================
# زر مساعد
# =========================================================

def make_button(text, callback=None, height=55):

    button = Button(
        text=text,
        size_hint_y=None,
        height=height,
        background_normal="",
        background_color=DARK_BLUE,
        color=WHITE,
        font_size=16,
    )

    if callback:
        button.bind(on_press=callback)

    return button


# =========================================================
# شاشة التحميل
# =========================================================

class LoadingScreen(Screen):

    def __init__(self, **kwargs):

        super().__init__(**kwargs)

        self.layout = BoxLayout(
            orientation="vertical",
            padding=30,
            spacing=20,
        )

        self.add_widget(self.layout)

        self.layout.add_widget(
            Label(
                text="TURBO DRIVE",
                font_size=32,
                color=BLUE,
            )
        )

        self.layout.add_widget(
            Label(
                text="CHALLENGE YOURSELF.\n"
                     "BECOME THE FASTEST.",
                font_size=18,
                color=WHITE,
            )
        )

        self.progress = ProgressBar(
            max=100,
            value=0,
            size_hint_y=None,
            height=25,
        )

        self.layout.add_widget(self.progress)

        self.percent = Label(
            text="0%",
            font_size=18,
            color=BLUE,
        )

        self.layout.add_widget(self.percent)

        self.layout.add_widget(
            Label(
                text="REACH YOUR LIMIT.\n"
                     "TAKE A SCREENSHOT AND SHARE IT.",
                font_size=14,
                color=WHITE,
            )
        )

        Clock.schedule_interval(
            self.loading_update,
            0.05
        )

    def loading_update(self, dt):

        self.progress.value += 2

        self.percent.text = (
            str(int(self.progress.value)) + "%"
        )

        if self.progress.value >= 100:

            Clock.unschedule(
                self.loading_update
            )

            self.manager.current = "home"


# =========================================================
# الشاشة الرئيسية
# =========================================================

class HomeScreen(Screen):

    def __init__(self, **kwargs):

        super().__init__(**kwargs)

        self.layout = BoxLayout(
            orientation="vertical",
            padding=25,
            spacing=15,
        )

        self.add_widget(self.layout)

        self.title = Label(
            text="TURBO DRIVE",
            font_size=32,
            color=BLUE,
            size_hint_y=None,
            height=60,
        )

        self.layout.add_widget(self.title)

        self.money_label = Label(
            text="$0.00",
            font_size=24,
            color=GOLD,
            size_hint_y=None,
            height=45,
        )

        self.layout.add_widget(
            self.money_label
        )

        self.multiplier_label = Label(
            text="MONEY x1",
            font_size=16,
            color=WHITE,
            size_hint_y=None,
            height=35,
        )

        self.layout.add_widget(
            self.multiplier_label
        )

        # -------------------------------------------------
        # زر المال
        # -------------------------------------------------

        self.money_button = Button(
            text="$",
            font_size=70,
            color=(0.15, 0.10, 0.02, 1),
            background_normal="",
            background_color=GOLD,
            size_hint=(None, None),
            size=(190, 190),
            pos_hint={"center_x": 0.5},
        )

        self.money_button.bind(
            on_press=self.collect_money
        )

        self.layout.add_widget(
            self.money_button
        )

        self.layout.add_widget(
            Label(
                text="TAP TO EARN",
                font_size=15,
                color=WHITE,
                size_hint_y=None,
                height=30,
            )
        )

        # -------------------------------------------------
        # الأزرار
        # -------------------------------------------------

        self.layout.add_widget(
            make_button(
                "MODIFICATIONS",
                self.open_modifications
            )
        )

        self.layout.add_widget(
            make_button(
                "CAR INFO",
                self.open_specs
            )
        )

    def on_pre_enter(self):

        self.refresh()

    def refresh(self):

        self.money_label.text = (
            "$" + f"{money:.2f}"
        )

        self.multiplier_label.text = (
            "MONEY x"
            + f"{get_profit_multiplier():.0f}"
        )

    def collect_money(self, instance):

        global money

        money += get_profit_multiplier()

        self.refresh()


    def open_modifications(self, instance):

        self.manager.current = "mods"


    def open_specs(self, instance):

        self.manager.current = "specs"


# =========================================================
# شاشة التعديلات
# =========================================================

class ModificationsScreen(Screen):

    def __init__(self, **kwargs):

        super().__init__(**kwargs)

        self.layout = BoxLayout(
            orientation="vertical",
            padding=15,
            spacing=10,
        )

        self.add_widget(self.layout)

        self.header = BoxLayout(
            size_hint_y=None,
            height=55,
        )

        self.title = Label(
            text="CAR MODIFICATIONS",
            font_size=22,
            color=BLUE,
        )

        self.money_label = Label(
            text="$0.00",
            font_size=18,
            color=GOLD,
        )

        self.header.add_widget(self.title)
        self.header.add_widget(self.money_label)

        self.layout.add_widget(self.header)

        # -------------------------------------------------
        # أزرار القطع
        # -------------------------------------------------

        self.parts_grid = GridLayout(
            cols=2,
            spacing=8,
            size_hint_y=None,
        )

        self.parts_grid.bind(
            minimum_height=self.parts_grid.setter(
                "height"
            )
        )

        self.layout.add_widget(
            self.parts_grid
        )

        for part in parts:

            button = make_button(
                part_names[part],
                lambda instance, p=part:
                self.select_part(p),
                height=60,
            )

            self.parts_grid.add_widget(button)

        # -------------------------------------------------
        # معلومات القطعة
        # -------------------------------------------------

        self.info_label = Label(
            text="",
            font_size=15,
            color=WHITE,
            halign="center",
            valign="middle",
        )

        self.info_label.bind(
            size=lambda instance, value:
            setattr(
                instance,
                "text_size",
                value
            )
        )

        self.layout.add_widget(
            self.info_label
        )

        # -------------------------------------------------
        # زر الشراء
        # -------------------------------------------------

        self.buy_button = make_button(
            "BUY",
            self.buy_upgrade,
            height=60,
        )

        self.layout.add_widget(
            self.buy_button
        )

        self.layout.add_widget(
            make_button(
                "BACK",
                self.go_back,
                height=50,
            )
        )

    def on_pre_enter(self):

        self.refresh()

    def select_part(self, part):

        global selected_part

        selected_part = part

        self.refresh()

    def refresh(self):

        self.money_label.text = (
            "$" + f"{money:.2f}"
        )

        level = car_levels[selected_part]

        price = get_price(selected_part)

        multiplier = part_multipliers[selected_part]

        total_bonus = (
            (level - 1) * multiplier
        )

        self.info_label.text = (
            f"{part_names[selected_part]}\n\n"
            f"LEVEL: {level}\n"
            f"{part_benefits[selected_part]}\n\n"
            f"THIS PART: +x{multiplier}\n"
            f"PART BONUS: +x{total_bonus}\n"
            f"TOTAL MONEY: x"
            f"{get_profit_multiplier():.0f}\n\n"
            f"NEXT UPGRADE: ${price}"
        )

        self.buy_button.text = (
            f"BUY  ${price}"
        )

    def buy_upgrade(self, instance):

        global money

        price = get_price(selected_part)

        if money >= price:

            money -= price

            car_levels[selected_part] += 1

            self.refresh()

        else:

            self.info_label.text = (
                f"NOT ENOUGH MONEY\n\n"
                f"YOU NEED ${price - money:.2f} MORE"
            )

    def go_back(self, instance):

        self.manager.current = "home"


# =========================================================
# شاشة معلومات السيارة
# =========================================================

class SpecsScreen(Screen):

    def __init__(self, **kwargs):

        super().__init__(**kwargs)

        self.layout = BoxLayout(
            orientation="vertical",
            padding=20,
            spacing=15,
        )

        self.add_widget(self.layout)

        self.layout.add_widget(
            Label(
                text="YOUR CAR",
                font_size=30,
                color=BLUE,
                size_hint_y=None,
                height=60,
            )
        )

        scroll = ScrollView()

        self.info = Label(
            text="",
            font_size=17,
            color=WHITE,
            halign="left",
            valign="top",
            size_hint_y=None,
        )

        self.info.bind(
            texture_size=lambda instance, value:
            setattr(
                instance,
                "height",
                value[1]
            )
        )

        self.info.bind(
            width=lambda instance, value:
            setattr(
                instance,
                "text_size",
                (value, None)
            )
        )

        scroll.add_widget(
            self.info
        )

        self.layout.add_widget(
            scroll
        )

        self.layout.add_widget(
            make_button(
                "BACK",
                self.go_back,
                height=55,
            )
        )

    def on_pre_enter(self):

        self.refresh()

    def refresh(self):

        self.info.text = (
            f"ENGINE\n"
            f"Level {car_levels['engine']}\n"
            f"Power bonus: +"
            f"{(car_levels['engine'] - 1) * 10}\n\n"

            f"TURBO\n"
            f"Level {car_levels['turbo']}\n"
            f"Maximum speed: "
            f"{get_speed()} KM/H\n\n"

            f"TIRES\n"
            f"Level {car_levels['tires']}\n"
            f"Control: {get_control()}%\n\n"

            f"BUMPER\n"
            f"Level {car_levels['bumper']}\n"
            f"Money bonus: +x"
            f"{(car_levels['bumper'] - 1) * 2}\n\n"

            f"HOOD\n"
            f"Level {car_levels['hood']}\n"
            f"Durability: "
            f"{get_durability()}%\n\n"

            f"FUEL TANK\n"
            f"Level {car_levels['fuel']}\n"
            f"Fuel: {get_fuel()}\n\n"

            f"--------------------------------\n\n"

            f"TOTAL MONEY MULTIPLIER\n"
            f"x{get_profit_multiplier():.0f}"
        )

    def go_back(self, instance):

        self.manager.current = "home"


# =========================================================
# التطبيق
# =========================================================

class TurboDriveApp(App):

    def build(self):

        self.title = "TURBO DRIVE"

        manager = ScreenManager()

        manager.add_widget(
            LoadingScreen(
                name="loading"
            )
        )

        manager.add_widget(
            HomeScreen(
                name="home"
            )
        )

        manager.add_widget(
            ModificationsScreen(
                name="mods"
            )
        )

        manager.add_widget(
            SpecsScreen(
                name="specs"
            )
        )

        return manager


# =========================================================
# تشغيل
# =========================================================

if __name__ == "__main__":

    TurboDriveApp().run()